# hotel_your_choice/choices.py

RATING_CHOICES = [(i, str(i)) for i in range(1, 6)]