default_app_config = 'hotel_your_choice.apps.HotelYourChoiceConfig'
